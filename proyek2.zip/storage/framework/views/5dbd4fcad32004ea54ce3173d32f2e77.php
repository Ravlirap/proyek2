<?php $__env->startSection('content'); ?>
<section class="form-section">
    <div class="container">
        <h1 class="page-title text-center">Tambah Artikel Baru</h1>

        <form action="<?php echo e(route('artikel.store')); ?>" method="POST" enctype="multipart/form-data" class="form-card">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="judul" class="form-label">Judul Artikel</label>
                <input type="text" name="judul" id="judul" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="isi" class="form-label">Isi Artikel</label>
                <textarea name="isi" id="isi" rows="6" class="form-control" required></textarea>
            </div>

            <div class="mb-3">
                <label for="gambar" class="form-label">Gambar (opsional)</label>
                <input type="file" name="gambar" id="gambar" class="form-control">
            </div>

            <div class="text-end">
                <a href="<?php echo e(route('artikel.index')); ?>" class="btn btn-secondary">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</section>

<style>
.form-section {
    padding-top: 140px;
    padding-bottom: 80px;
    background: #fff;
}
.form-card {
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.08);
    max-width: 700px;
    margin: 0 auto;
}
.page-title {
    margin-bottom: 30px;
    font-weight: 700;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\proyek2\resources\views/content/artikel/create.blade.php ENDPATH**/ ?>