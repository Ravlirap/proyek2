<?php $__env->startSection('content'); ?>
<style>
body {
    padding-top: 140px;
}
</style>
<div class="container py-5">
    <a href="<?php echo e(route('galeri.index')); ?>" class="btn btn-outline-secondary mb-3">← Kembali</a>

    <div class="card shadow-sm">
        <?php if($galeri->gambar): ?>
            <img src="<?php echo e(asset('storage/' . $galeri->gambar)); ?>" class="card-img-top" alt="<?php echo e($galeri->judul); ?>" style="max-height: 450px; object-fit: cover;">
        <?php endif; ?>
        <div class="card-body text-center">
            <h3 class="card-title mb-3"><?php echo e($galeri->judul); ?></h3>
            <p class="text-muted"><?php echo e($galeri->deskripsi); ?></p>
            <p class="small text-secondary">Diupload pada <?php echo e($galeri->created_at->format('d M Y')); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\proyek2\resources\views/content/galeri/show.blade.php ENDPATH**/ ?>